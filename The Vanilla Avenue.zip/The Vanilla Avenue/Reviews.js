
  const myform=document.querySelector('#my-form')
  const nameinput=document.querySelector('#name')
  const emailinput=document.querySelector('#email')
  const Review=document.querySelector('#review')
  const msg=document.querySelector('.msg')
const userlist=document.querySelector('#users')

 myform.addEventListener('submit',onsubmit);

 function onsubmit(e){
     e.preventDefault()
     console.log(nameinput.value);
     console.log(emailinput.value);

    if(nameinput.value==='' || emailinput.value === ''|| Review.value==="") {
        msg.innerHTML='Please fill the complete detail'
        msg.classList.add('error')
        setTimeout(()=> msg.remove(),2500)
    }
     else{
          const li=document.createElement('li')
          li.appendChild(document.createTextNode(`${nameinput.value}-${emailinput.value}-${Review.value}`));
          userlist.appendChild(li);

//           //clear field
          nameinput.value=''
          emailinput.value=''

     }
 }

